#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern double multiplier(int n, double vA[], double vB[]);

int main() {
    int x = 0, n = 0, count = 0;
    char ch = '\0', input[257];
    char* token;
    double* vectorA = NULL;
    double* vectorB = NULL;
    double answer = 0.0;

    do {
        if (scanf_s("%c", &ch, (unsigned int)sizeof(ch)) != 1) {
            break;
        }
        if (ch != '\n' && x < 256) {
            input[x] = ch;
            x++;
        }
    } while (ch != '\n');
    input[x] = '\0';

    token = strtok(input, " ");
    if (token != NULL) {
        n = atoi(token);
    }

    if (n <= 0) {
        printf("Invalid vector size.\n");
        return 1;
    }

    vectorA = (double*)malloc(n * sizeof(*vectorA));
    vectorB = (double*)malloc(n * sizeof(*vectorB));

    if (vectorA == NULL || vectorB == NULL) {
        printf("Memory allocation failed.\n");
        free(vectorA);
        free(vectorB);
        return 1;
    }

    while ((token = strtok(NULL, " ")) != NULL) {
        double value = strtod(token, NULL);
        if (count < n) {
            vectorA[count] = value;
        }
        else if ((count - n) < n) {
            vectorB[count - n] = value;
        }
        count++;
    }

    answer = multiplier(n, vectorA, vectorB);

    printf("Dot Product: %f\n", answer);

    free(vectorA);
    free(vectorB);

    return 0;
}